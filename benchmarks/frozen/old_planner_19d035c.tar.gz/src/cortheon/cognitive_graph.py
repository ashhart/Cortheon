"""Small, memory-only primitives for inspectable test-time reasoning."""

from __future__ import annotations

import hashlib
import json
import math
from collections import deque
from collections.abc import Iterable, Mapping
from typing import Any


def content_id(prefix: str, value: Any) -> str:
    encoded = json.dumps(
        value,
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode()
    return f"{prefix}_{hashlib.sha256(encoded).hexdigest()[:16]}"


def _entropy(weights: Iterable[float]) -> float:
    values = [value for value in weights if value > 0]
    total = sum(values)
    return (
        -sum((value / total) * math.log2(value / total) for value in values)
        if total
        else 0.0
    )


def rank_information_gain(
    hypotheses: Mapping[str, float],
    actions: Iterable[Mapping[str, Any]],
) -> list[dict[str, Any]]:
    """Rank evidence actions by expected entropy reduction per unit cost.

    An action may provide explicit ``partitions``: groups of hypotheses that
    remain indistinguishable for each possible result. Alternatively,
    ``resolves`` names hypotheses the action can distinguish individually.
    """

    weights = {key: max(0.0, float(value)) for key, value in hypotheses.items()}
    if not any(weights.values()):
        weights = dict.fromkeys(weights, 1.0)
    prior = _entropy(weights.values())
    ranked: list[dict[str, Any]] = []
    for index, action in enumerate(actions):
        partitions = action.get("partitions")
        reported_resolves: set[str] = set()
        if not isinstance(partitions, (list, tuple)):
            resolved = {
                str(item)
                for item in action.get("resolves", ())
                if str(item) in weights
            }
            reported_resolves = resolved
            partitions = [[item] for item in sorted(resolved)]
            unresolved = sorted(set(weights) - resolved)
            if unresolved:
                partitions.append(unresolved)
        seen: set[str] = set()
        expected = 0.0
        total = sum(weights.values())
        for group in partitions:
            members = [
                str(item)
                for item in group
                if str(item) in weights and str(item) not in seen
            ]
            seen.update(members)
            mass = sum(weights[item] for item in members)
            if total and mass:
                expected += (mass / total) * _entropy(weights[item] for item in members)
        omitted = sorted(set(weights) - seen)
        omitted_mass = sum(weights[item] for item in omitted)
        if total and omitted_mass:
            expected += (omitted_mass / total) * _entropy(weights[item] for item in omitted)
        gain = max(0.0, prior - expected)
        cost = max(0.001, float(action.get("cost", 1.0)))
        reliability = min(1.0, max(0.0, float(action.get("reliability", 1.0))))
        ranked.append(
            {
                "action_id": str(action.get("action_id") or f"action_{index + 1}"),
                "information_gain_bits": round(gain, 6),
                "expected_utility": round(gain * reliability / cost, 6),
                "cost": cost,
                "reliability": reliability,
                "resolves": sorted(reported_resolves),
            }
        )
    return sorted(
        ranked,
        key=lambda item: (-item["expected_utility"], -item["information_gain_bits"], item["action_id"]),
    )


class CognitiveGraph:
    """A bounded proposition graph with provenance and deterministic identity."""

    def __init__(self) -> None:
        self._nodes: dict[str, dict[str, Any]] = {}
        self._edges: set[tuple[str, str, str, str, bool]] = set()

    def add_node(self, node_id: str, kind: str, label: str, **state: Any) -> str:
        self._nodes[node_id] = {
            "node_id": node_id,
            "kind": kind,
            "label": label,
            **{key: value for key, value in state.items() if value is not None},
        }
        return node_id

    def proposition(self, subject: str, relation: str, target: str) -> tuple[str, str]:
        source_id = content_id("p", {"label": subject})
        target_id = content_id("p", {"label": target})
        self.add_node(source_id, "proposition", subject)
        self.add_node(target_id, "proposition", target)
        self.add_edge(source_id, relation, target_id, functional=True)
        return source_id, target_id

    def add_edge(
        self,
        source: str,
        relation: str,
        target: str,
        *,
        evidence_id: str = "",
        functional: bool = False,
    ) -> None:
        if source not in self._nodes or target not in self._nodes:
            raise ValueError("graph edges require existing nodes")
        self._edges.add((source, relation, target, evidence_id, functional))

    def proof_path(self, source: str, target: str) -> list[dict[str, Any]]:
        adjacent: dict[str, list[tuple[str, str, str]]] = {}
        for start, relation, end, evidence_id, _functional in self._edges:
            adjacent.setdefault(start, []).append((end, relation, evidence_id))
        queue = deque([(source, [])])
        visited = {source}
        while queue:
            node, path = queue.popleft()
            if node == target:
                return path
            for end, relation, evidence_id in sorted(adjacent.get(node, ())):
                if end in visited:
                    continue
                visited.add(end)
                queue.append(
                    (
                        end,
                        [
                            *path,
                            {
                                "from": node,
                                "relation": relation,
                                "to": end,
                                **({"evidence_id": evidence_id} if evidence_id else {}),
                            },
                        ],
                    )
                )
        return []

    def snapshot(self) -> dict[str, Any]:
        nodes = [self._nodes[key] for key in sorted(self._nodes)]
        edges = [
            {
                "from": source,
                "relation": relation,
                "to": target,
                **({"evidence_id": evidence_id} if evidence_id else {}),
                **({"functional": True} if functional else {}),
            }
            for source, relation, target, evidence_id, functional in sorted(self._edges)
        ]
        targets: dict[tuple[str, str], set[str]] = {}
        evidence: dict[tuple[str, str], set[str]] = {}
        for source, relation, target, evidence_id, functional in self._edges:
            if not functional:
                continue
            targets.setdefault((source, relation), set()).add(target)
            if evidence_id:
                evidence.setdefault((source, relation), set()).add(evidence_id)
        contradictions = [
            {
                "source": source,
                "relation": relation,
                "targets": sorted(values),
                "evidence_ids": sorted(evidence.get((source, relation), ())),
            }
            for (source, relation), values in sorted(targets.items())
            if len(values) > 1
        ]
        graph = {"nodes": nodes, "edges": edges, "contradictions": contradictions}
        return {
            **graph,
            "digest": content_id("cg", graph),
            "node_count": len(nodes),
            "edge_count": len(edges),
        }
