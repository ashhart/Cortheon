"""Versioned public contract for Cortheon's memory-only cognitive runtime."""

from __future__ import annotations

CORTHEON_PROTOCOL_VERSION = "1.0.0"
CORTHEON_PROTOCOL_MAJOR = 1
CORTHEON_STORAGE_MODEL = "memory_only"
CORTHEON_CERTIFICATION_SCOPE = "bounded_evidence_contract"


def protocol_capabilities() -> dict[str, object]:
    """Return stable, machine-readable runtime capabilities."""

    return {
        "protocol_version": CORTHEON_PROTOCOL_VERSION,
        "protocol_major": CORTHEON_PROTOCOL_MAJOR,
        "storage": CORTHEON_STORAGE_MODEL,
        "certification_scope": CORTHEON_CERTIFICATION_SCOPE,
        "owns_project_tools": False,
        "owns_project_files": False,
        "persists_task_state": False,
        "native_adapter_leases": True,
        "telemetry": "content_free_local",
        "adaptive_cognition": {
            "stages": [
                "orient",
                "frame",
                "discover",
                "update",
                "connect",
                "challenge",
                "synthesize",
                "verify",
            ],
            "cross_source_derivation": True,
            "explicit_alias_resolution": True,
            "conjunctive_rule_derivation": True,
            "markdown_table_synthesis": True,
            "adaptive_document_discovery": True,
            "adaptive_code_discovery": True,
            "requirement_level_completion_coverage": True,
            "contradiction_driven_replanning": True,
            "competing_hypotheses": True,
            "substrate_abductive_origination": True,
            "originated_hypothesis_provenance": True,
            "ephemeral_cognitive_graph": True,
            "information_gain_planning": True,
            "task_program_compilation": True,
            "host_owned_tools": True,
        },
        "evidence_assurance": {
            "opencode": "enforced_adapter",
            "pi": "enforced_adapter",
            "codex": "enforced_hooks_with_local_http_runtime",
            "stdio_mcp": "cooperative",
            "generic_http": "cooperative",
        },
        "task_kinds": [
            "auto",
            "code",
            "research",
            "documents",
            "decision",
            "general",
        ],
        "transports": ["stdio_mcp", "http_json"],
    }
