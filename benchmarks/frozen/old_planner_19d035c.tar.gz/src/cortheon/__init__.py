"""Cortheon: test-time cognitive infrastructure for harness-hosted models.

The ``cortheon-mcp`` surface keeps a bounded, ephemeral investigation graph that
requests live evidence, challenges conclusions, and gates completion. The
harness owns models, tools, permissions, and execution; that runtime stores no
project files.
"""

__version__ = "0.1.0"
