"""Memory-only coordination for host-enforced Cortheon lifecycle hooks."""

from __future__ import annotations

import contextlib
import copy
import hashlib
import json
import re
import shlex
import threading
import time
from dataclasses import dataclass, field
from typing import Any

from cortheon.cognitive_repair import (
    RepairPlan,
    TestInvocation,
    changed_paths_from_diff,
    derive_repair_candidates,
    is_test_path,
    protected_test_paths,
    protects_tests,
    requested_check_invocation,
    requested_test_invocation,
)

CORTHEON_PHASE_TOOLS = {
    "start": "cortheon_start",
    "observe": "cortheon_observe",
    "complete": "cortheon_complete",
    "abandon": "cortheon_abandon",
}
MAX_TOOL_DENIALS_PER_TURN = 3
MAX_STOP_CONTINUATIONS_PER_TURN = 2
MAX_PATCH_STOP_CONTINUATIONS_PER_TURN = 4
MAX_TURN_FAILURES_PER_HOST_SESSION = 3
MAX_HOOK_EVIDENCE_CHARS = 8_000
_FILE_MARKER_PREFIX = "[CORTHEON_FILE:"
UNCERTIFIED_RELEASE_CAVEAT = (
    "Cortheon could not certify this answer: the live evidence contract was not "
    "satisfied within the turn's continuation budget. Treat specific claims as "
    "unverified."
)


def cortheon_tool_phase(tool_name: str) -> str | None:
    """Return the Cortheon lifecycle phase represented by a host tool name."""

    normalized = tool_name.strip().lower()
    for phase, suffix in CORTHEON_PHASE_TOOLS.items():
        if normalized == suffix or normalized.endswith(f"__{suffix}"):
            return phase
    return None


def _bounded_cognition(payload: dict[str, Any]) -> dict[str, Any] | None:
    stage = payload.get("stage")
    if not isinstance(stage, str) or not stage:
        return None
    moves = payload.get("reasoning_moves")
    move = (
        next((item for item in moves if isinstance(item, str) and item), "")
        if isinstance(moves, list)
        else ""
    )
    insights = payload.get("derived_insights")
    insight = ""
    if isinstance(insights, list):
        first = next((item for item in insights if isinstance(item, dict)), None)
        if isinstance(first, dict) and isinstance(first.get("statement"), str):
            insight = first["statement"]
    decision_rule = payload.get("decision_rule")
    return {
        "stage": stage[:32],
        "move": move[:400],
        "derived_insight": insight[:600],
        "decision_rule": (
            decision_rule[:500] if isinstance(decision_rule, str) else ""
        ),
    }


@dataclass(slots=True)
class HookTurn:
    """Bounded in-memory task state; never persisted by Cortheon."""

    host_session_hash: str
    goal_hash: str = ""
    started: bool = False
    observed: bool = False
    certified: bool = False
    automatic: bool = False
    cortheon_session_id: str | None = None
    pending_request: dict[str, Any] | None = None
    pending_origin: str | None = None
    pending_host_command: str = ""
    pending_host_input: dict[str, Any] = field(default_factory=dict)
    read_snapshots: dict[str, str] = field(default_factory=dict)
    last_next_action: dict[str, Any] | None = None
    cognition: dict[str, Any] | None = None
    evidence_ids: list[str] = field(default_factory=list)
    last_success_condition: str = ""
    awaiting_host_result: bool = False
    deliverable: str = ""
    repair_plan: RepairPlan | None = None
    repair_candidates: list[RepairPlan] = field(default_factory=list)
    repair_candidate_index: int = 0
    test_invocation: TestInvocation | None = None
    check_invocation: TestInvocation | None = None
    check_pending: bool = False
    protected_test_paths: tuple[str, ...] = ()
    protects_all_tests: bool = False
    patch_applied: bool = False
    tool_denials: int = 0
    stop_continuations: int = 0
    updated_at: float = 0.0


class CognitiveHookTracker:
    """Enforce and, when possible, drive Cortheon through host lifecycle hooks."""

    def __init__(
        self,
        *,
        runtime: Any | None = None,
        max_turns: int = 512,
        ttl_seconds: float = 1_800.0,
    ) -> None:
        if not 1 <= max_turns <= 100_000:
            raise ValueError("max_turns must be between 1 and 100000")
        if not 1.0 <= ttl_seconds <= 86_400.0:
            raise ValueError("ttl_seconds must be between 1 and 86400")
        self.runtime = runtime
        self.max_turns = max_turns
        self.ttl_seconds = ttl_seconds
        self._turns: dict[str, HookTurn] = {}
        self._session_failures: dict[str, int] = {}
        self._lock = threading.RLock()
        self._metrics = {
            "hook_turns_registered": 0,
            "hook_turns_certified": 0,
            "hook_tools_denied": 0,
            "hook_continuations": 0,
            "hook_turns_expired": 0,
            "hook_auto_started": 0,
            "hook_auto_observations": 0,
            "hook_auto_completed": 0,
            "hook_auto_withheld": 0,
            "hook_auto_repairs_derived": 0,
            "hook_auto_repair_candidates_advanced": 0,
            "hook_auto_patches_applied": 0,
            "hook_auto_edit_reconciliations": 0,
            "hook_auto_tests_passed": 0,
            "hook_auto_checks_scheduled": 0,
            "hook_auto_checks_passed": 0,
            "hook_protected_mutations_denied": 0,
            "hook_uncertified_releases": 0,
            "hook_degraded_registrations": 0,
        }

    @property
    def active_turns(self) -> int:
        with self._lock:
            self._purge_expired()
            return len(self._turns)

    @property
    def metrics(self) -> dict[str, int]:
        with self._lock:
            self._purge_expired()
            return {**self._metrics, "active_hook_turns": len(self._turns)}

    def register(
        self,
        host: str,
        host_session_id: str,
        turn_id: str,
        *,
        goal: str | None = None,
        effort: str = "quick",
        strictness: str = "standard",
        task_kind: str = "auto",
    ) -> dict[str, Any]:
        key, host_hash = self._identifiers(host, host_session_id, turn_id)
        normalized_goal = _bounded(goal, "goal", maximum=8_000) if goal is not None else None
        goal_hash = (
            hashlib.sha256(normalized_goal.casefold().encode()).hexdigest()
            if normalized_goal is not None
            else ""
        )
        with self._lock:
            self._purge_expired()
            if self._session_failures.get(host_hash, 0) >= MAX_TURN_FAILURES_PER_HOST_SESSION:
                self._metrics["hook_degraded_registrations"] += 1
                return {
                    "tracked": False,
                    "degraded": True,
                    "started": False,
                    "observed": False,
                    "certified": False,
                    "automatic": False,
                    "reason": (
                        "Cortheon degraded to passthrough for this host session after "
                        "repeated uncertified turns."
                    ),
                }
            state = self._turns.get(key)
            if state is None:
                prior = next(
                    (
                        (prior_key, prior_state)
                        for prior_key, prior_state in self._turns.items()
                        if prior_state.host_session_hash == host_hash
                        and prior_state.automatic
                        and not prior_state.certified
                    ),
                    None,
                )
                if prior is not None and (
                    goal_hash == "" or not prior[1].goal_hash or prior[1].goal_hash == goal_hash
                ):
                    # Same in-flight investigation continuing on a fresh turn:
                    # keep its evidence but grant a fresh continuation budget.
                    prior_key, state = prior
                    del self._turns[prior_key]
                    self._turns[key] = state
                    state.stop_continuations = 0
                    state.tool_denials = 0
                elif prior is not None:
                    # A different goal arrived; the stale investigation must not
                    # poison it, so discard instead of migrating.
                    prior_key, prior_state = prior
                    del self._turns[prior_key]
                    self._discard_runtime_session(prior_state)
                if state is None:
                    if len(self._turns) >= self.max_turns:
                        self._evict_oldest()
                    state = HookTurn(
                        host_session_hash=host_hash,
                        goal_hash=goal_hash,
                        updated_at=time.monotonic(),
                    )
                    self._turns[key] = state
                    self._metrics["hook_turns_registered"] += 1
            state.updated_at = time.monotonic()
            if (
                normalized_goal is not None
                and self.runtime is not None
                and state.cortheon_session_id is None
            ):
                started = self.runtime.start(
                    normalized_goal,
                    effort=effort,
                    task_kind=task_kind,
                    strictness=strictness,
                )
                state.started = True
                state.automatic = True
                state.goal_hash = goal_hash
                state.cortheon_session_id = str(started["session"]["session_id"])
                state.deliverable = str(started.get("session", {}).get("deliverable") or "")
                state.test_invocation = requested_test_invocation(normalized_goal)
                state.check_invocation = requested_check_invocation(normalized_goal)
                state.protected_test_paths = protected_test_paths(normalized_goal)
                state.protects_all_tests = protects_tests(normalized_goal)
                self._capture_next_action(state, started)
                self._metrics["hook_auto_started"] += 1
            return self._response(state)

    def pre_tool(
        self,
        host: str,
        host_session_id: str,
        turn_id: str,
        tool_name: str,
        *,
        tool_input: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        key, _host_hash = self._identifiers(host, host_session_id, turn_id)
        normalized_tool = _bounded(tool_name, "tool_name")
        phase = cortheon_tool_phase(normalized_tool)
        with self._lock:
            self._purge_expired()
            state = self._turns.get(key)
            if state is None:
                return {"tracked": False, "allow": True}
            state.updated_at = time.monotonic()
            if state.certified or phase is not None:
                return {"tracked": True, "allow": True, **self._response(state)}
            if state.automatic:
                return self._automatic_pre_tool(
                    state,
                    normalized_tool,
                    tool_input=tool_input or {},
                )
            if not state.started:
                return self._nudge_start(state)
            return {"tracked": True, "allow": True, **self._response(state)}

    def post_tool(
        self,
        host: str,
        host_session_id: str,
        turn_id: str,
        tool_name: str,
        *,
        succeeded: bool,
        certified: bool = False,
        tool_output: str = "",
    ) -> dict[str, Any]:
        key, _host_hash = self._identifiers(host, host_session_id, turn_id)
        normalized_tool = _bounded(tool_name, "tool_name")
        if not isinstance(tool_output, str):
            raise ValueError("tool_output must be a string")
        phase = cortheon_tool_phase(normalized_tool)
        with self._lock:
            self._purge_expired()
            state = self._turns.get(key)
            if state is None:
                return {"tracked": False}
            state.updated_at = time.monotonic()
            if state.automatic and phase is None:
                return self._automatic_post_tool(
                    state,
                    normalized_tool,
                    succeeded=succeeded,
                    tool_output=tool_output,
                )
            if succeeded and phase == "start":
                state.started = True
            elif succeeded and phase == "observe" and state.started:
                state.observed = True
            elif (
                succeeded and certified and phase == "complete" and state.started and state.observed
            ):
                self._mark_certified(state)
            return {"tracked": True, **self._response(state)}

    def stop(
        self,
        host: str,
        host_session_id: str,
        turn_id: str,
        *,
        answer: str | None = None,
    ) -> dict[str, Any]:
        key, _host_hash = self._identifiers(host, host_session_id, turn_id)
        with self._lock:
            self._purge_expired()
            state = self._turns.get(key)
            if state is None:
                return {"tracked": False, "allow": True}
            if state.automatic:
                return self._automatic_stop(key, state, answer)
            if state.certified:
                del self._turns[key]
                return {"tracked": True, "allow": True, "certified": True}
            return self._manual_stop(key, state)

    def end_session(self, host: str, host_session_id: str) -> dict[str, Any]:
        host_hash = self._host_hash(host, host_session_id)
        with self._lock:
            matching = [
                (key, state)
                for key, state in self._turns.items()
                if state.host_session_hash == host_hash
            ]
            for key, state in matching:
                self._discard_runtime_session(state)
                del self._turns[key]
            self._session_failures.pop(host_hash, None)
            return {"ok": True, "removed_turns": len(matching)}

    def _automatic_pre_tool(
        self,
        state: HookTurn,
        tool_name: str,
        *,
        tool_input: dict[str, Any],
    ) -> dict[str, Any]:
        if _attempts_protected_mutation(
            tool_name,
            tool_input,
            protected_paths=state.protected_test_paths,
            protects_all_tests=state.protects_all_tests,
        ):
            state.tool_denials += 1
            self._metrics["hook_tools_denied"] += 1
            self._metrics["hook_protected_mutations_denied"] += 1
            return {
                "tracked": True,
                "allow": False,
                "reason": (
                    "Cortheon blocked a mutation to a user-protected test file. "
                    "Change only the implementation and preserve the test."
                ),
                **self._response(state),
            }
        if (
            state.awaiting_host_result
            and state.pending_origin == "adapter"
            and str((state.pending_request or {}).get("capability") or "") == "edit"
            and state.repair_plan is not None
        ):
            state.awaiting_host_result = False
            self._metrics["hook_auto_edit_reconciliations"] += 1
            self._schedule_adapter_request(
                state,
                capability="diff",
                query=(
                    "The host edit path did not emit a usable result event. "
                    f"Inspect the live Git diff for {state.repair_plan.path} "
                    "instead of assuming the edit succeeded."
                ),
                success_condition=(
                    "Return a non-empty Git diff proving the implementation "
                    "change and showing that protected tests were untouched."
                ),
                parameters={"path": state.repair_plan.path},
            )
        request = state.pending_request
        if request is None:
            state.awaiting_host_result = False
            state.pending_host_command = ""
            state.pending_host_input = {}
            return {"tracked": True, "allow": True, **self._response(state)}
        capability = str(request.get("capability") or "")
        if capability == "edit":
            return self._automatic_edit_pre_tool(state, tool_name)
        # The strict phase is the adapter-driven patch loop (diff/test/edit).
        # Runtime-issued investigation requests stay lenient: the model may run
        # its own commands and the hook harvests the results as evidence.
        strict = state.pending_origin == "adapter"
        if _is_shell_tool(tool_name):
            if strict:
                command = _safe_command(request)
                if command is not None:
                    state.awaiting_host_result = True
                    state.pending_host_command = ""
                    state.pending_host_input = {}
                    response = {"tracked": True, "allow": True, **self._response(state)}
                    response["updated_input"] = {"command": command}
                    return response
                state.awaiting_host_result = False
                state.pending_host_input = {}
                return self._deny_requested_capability(state, capability)
            state.awaiting_host_result = True
            state.pending_host_command = str(
                tool_input.get("command") or tool_input.get("cmd") or ""
            )[:500]
            state.pending_host_input = copy.deepcopy(tool_input)
            return {"tracked": True, "allow": True, **self._response(state)}
        if strict:
            state.pending_host_input = {}
            return self._deny_requested_capability(state, capability)
        # Purpose-built read/search tools are model-owned too. Preserve their
        # structured input so the receipt records what actually ran.
        state.awaiting_host_result = True
        state.pending_host_command = ""
        state.pending_host_input = copy.deepcopy(tool_input)
        return {"tracked": True, "allow": True, **self._response(state)}

    def _automatic_edit_pre_tool(
        self,
        state: HookTurn,
        tool_name: str,
    ) -> dict[str, Any]:
        plan = state.repair_plan
        if plan is None:
            return self._deny_requested_capability(state, "edit")
        patch = plan.patch()
        state.awaiting_host_result = True
        state.pending_host_input = {}
        response = {"tracked": True, "allow": True, **self._response(state)}
        if _is_apply_patch_tool(tool_name):
            response["updated_input"] = {"patch": patch}
            return response
        if _is_shell_tool(tool_name):
            response["updated_input"] = {
                "command": (f"apply_patch <<'CORTHEON_PATCH'\n{patch}CORTHEON_PATCH")
            }
            return response
        state.awaiting_host_result = False
        return self._deny_requested_capability(state, "edit")

    def _automatic_post_tool(
        self,
        state: HookTurn,
        tool_name: str,
        *,
        succeeded: bool,
        tool_output: str,
    ) -> dict[str, Any]:
        request = state.pending_request
        if not state.awaiting_host_result or request is None or state.cortheon_session_id is None:
            return {"tracked": True, **self._response(state)}
        state.awaiting_host_result = False
        host_command = state.pending_host_command
        state.pending_host_command = ""
        host_input = state.pending_host_input
        state.pending_host_input = {}
        capability = str(request.get("capability") or "")
        origin = state.pending_origin
        if capability == "edit":
            if succeeded and state.repair_plan is not None:
                state.patch_applied = True
                self._metrics["hook_auto_patches_applied"] += 1
                self._schedule_adapter_request(
                    state,
                    capability="diff",
                    query=(f"Capture the focused live diff for {state.repair_plan.path}."),
                    success_condition=(
                        "Return a non-empty Git diff proving the implementation "
                        "change and showing that protected tests were untouched."
                    ),
                    parameters={"path": state.repair_plan.path},
                )
            else:
                self._clear_pending_request(state)
                state.last_next_action = {
                    "type": "reason",
                    "instruction": (
                        "The bounded host edit failed. Inspect the failure, revise "
                        "the implementation repair, and do not claim completion."
                    ),
                }
            return {"tracked": True, **self._response(state)}
        if not succeeded and capability != "grep" and origin == "adapter":
            if (
                capability == "test"
                and not state.check_pending
                and state.repair_candidates
                and state.repair_candidate_index + 1 < len(state.repair_candidates)
            ):
                # Best-of-N: several candidates satisfied the observed
                # examples; the real test suite is the judge. Swap the
                # failed candidate for the next-ranked one and rerun the
                # verified edit -> diff -> test loop.
                current = state.repair_candidates[state.repair_candidate_index]
                state.repair_candidate_index += 1
                successor = state.repair_candidates[state.repair_candidate_index]
                state.repair_plan = RepairPlan(
                    path=successor.path,
                    old_text=current.new_text,
                    new_text=successor.new_text,
                    function_name=successor.function_name,
                    examples=successor.examples,
                )
                self._metrics["hook_auto_repair_candidates_advanced"] += 1
                self._schedule_adapter_request(
                    state,
                    capability="edit",
                    query=(
                        "The previous candidate repair failed the real test "
                        f"suite; apply the next verified candidate to {successor.path}."
                    ),
                    success_condition=(
                        f"Change only {successor.path}; preserve every protected test."
                    ),
                    parameters={
                        "path": successor.path,
                        "function": successor.function_name,
                        "examples": successor.examples,
                    },
                )
                return {"tracked": True, **self._response(state)}
            state.check_pending = False
            self._clear_pending_request(state)
            state.last_next_action = {
                "type": "reason",
                "instruction": (
                    f"The host {capability or 'evidence'} operation failed. "
                    "Correct the implementation or command, then gather fresh "
                    "diff and test evidence."
                ),
            }
            return {"tracked": True, **self._response(state)}
        observations = _host_observations(
            request,
            tool_name,
            tool_output,
            succeeded=succeeded,
            host_command=host_command,
            host_input=host_input,
        )
        if not observations:
            return {"tracked": True, **self._response(state)}
        runtime = self.runtime
        if runtime is None:
            return {"tracked": True, **self._response(state)}
        try:
            observed = runtime.observe(
                state.cortheon_session_id,
                observations,
                request_id=(
                    str(request["request_id"])
                    if origin == "runtime" and request.get("request_id")
                    else None
                ),
            )
        except (KeyError, RuntimeError, ValueError) as exc:
            return {
                "tracked": True,
                "observation_error": str(exc)[:500],
                **self._response(state),
            }
        accepted = [str(item) for item in observed.get("accepted_evidence_ids", ())]
        if all(item.get("status") != "failed" for item in observations):
            state.evidence_ids.extend(item for item in accepted if item not in state.evidence_ids)
        state.observed = bool(state.evidence_ids)
        self._capture_next_action(state, observed)
        self._metrics["hook_auto_observations"] += len(accepted)
        if capability == "read_many":
            for path, content in _read_snapshots(observations):
                state.read_snapshots[path] = content
        response_request = (observed.get("next_action") or {}).get("request")
        read_still_pending = (
            isinstance(response_request, dict)
            and response_request.get("request_id") == request.get("request_id")
        )
        if (
            capability == "read_many"
            and state.deliverable == "code_change"
            and not read_still_pending
        ):
            plans = derive_repair_candidates(list(state.read_snapshots.items()))
            plan = plans[0] if plans else None
            if plan is not None and state.test_invocation is not None:
                state.repair_plan = plan
                state.repair_candidates = plans
                state.repair_candidate_index = 0
                self._metrics["hook_auto_repairs_derived"] += 1
                self._schedule_adapter_request(
                    state,
                    capability="edit",
                    query=(
                        f"Apply the bounded one-line repair to {plan.path}; "
                        "the host hook will provide the exact patch."
                    ),
                    success_condition=(f"Change only {plan.path}; preserve every protected test."),
                    parameters={
                        "path": plan.path,
                        "function": plan.function_name,
                        "examples": plan.examples,
                    },
                )
        elif capability == "diff" and origin == "adapter":
            changed_paths = changed_paths_from_diff(tool_output)
            if (
                changed_paths
                and not self._protected_diff_paths(state, changed_paths)
                and state.test_invocation is not None
            ):
                if not state.patch_applied:
                    state.patch_applied = True
                    self._metrics["hook_auto_patches_applied"] += 1
                self._schedule_adapter_request(
                    state,
                    capability="test",
                    query=(
                        "Run the exact test command requested by the user after "
                        "the captured final diff."
                    ),
                    success_condition=("Return exit status zero and the focused passing summary."),
                    parameters={
                        "command": [
                            state.test_invocation.executable,
                            *state.test_invocation.arguments,
                        ]
                    },
                )
            else:
                self._clear_pending_request(state)
                state.last_next_action = {
                    "type": "reason",
                    "instruction": (
                        "The diff was empty or touched a protected test. Restore "
                        "the tests and produce an implementation-only change."
                    ),
                }
        elif capability == "test" and origin == "adapter":
            self._clear_pending_request(state)
            if succeeded:
                was_check_step = state.check_pending
                state.check_pending = False
                if was_check_step:
                    self._metrics["hook_auto_checks_passed"] += 1
                else:
                    self._metrics["hook_auto_tests_passed"] += 1
                if not was_check_step and state.check_invocation is not None:
                    # Chain the user's requested quality check as one more
                    # deterministic adapter step after the tests pass.
                    state.check_pending = True
                    self._metrics["hook_auto_checks_scheduled"] += 1
                    self._schedule_adapter_request(
                        state,
                        capability="test",
                        query=(
                            "Run the exact quality check requested by the user "
                            "after the passing test."
                        ),
                        success_condition=(
                            "Return exit status zero from the requested lint or "
                            "type check."
                        ),
                        parameters={
                            "command": [
                                state.check_invocation.executable,
                                *state.check_invocation.arguments,
                            ]
                        },
                    )
                else:
                    state.last_next_action = {
                        "type": "finish",
                        "instruction": (
                            "The host captured the final diff and a post-change passing "
                            "test. Report the concrete change and verified result."
                        ),
                    }
        return {"tracked": True, **self._response(state)}

    @staticmethod
    def _protected_diff_paths(
        state: HookTurn,
        changed_paths: set[str],
    ) -> set[str]:
        return {
            path
            for path in changed_paths
            if path in state.protected_test_paths
            or (state.protects_all_tests and is_test_path(path))
        }

    @staticmethod
    def _clear_pending_request(state: HookTurn) -> None:
        state.pending_request = None
        state.pending_origin = None

    @staticmethod
    def _schedule_adapter_request(
        state: HookTurn,
        *,
        capability: str,
        query: str,
        success_condition: str,
        parameters: dict[str, Any],
    ) -> None:
        state.pending_request = {
            "request_id": f"hook_{capability}",
            "capability": capability,
            "query": query,
            "reason": "Close the next observable host-side patch-loop gate.",
            "success_condition": success_condition,
            "parameters": copy.deepcopy(parameters),
            "status": "pending",
        }
        state.pending_origin = "adapter"
        state.last_success_condition = success_condition[:1_500]
        state.last_next_action = {
            "type": "harness_tool",
            "instruction": (
                "Run this exact operation with the host. The Cortheon hook will "
                "capture and verify the result automatically."
            ),
            "request": copy.deepcopy(state.pending_request),
        }

    def _automatic_stop(
        self,
        key: str,
        state: HookTurn,
        answer: str | None,
    ) -> dict[str, Any]:
        state.updated_at = time.monotonic()
        if (
            state.awaiting_host_result
            and state.pending_origin == "adapter"
            and str((state.pending_request or {}).get("capability") or "") == "edit"
            and state.repair_plan is not None
        ):
            state.awaiting_host_result = False
            self._metrics["hook_auto_edit_reconciliations"] += 1
            self._schedule_adapter_request(
                state,
                capability="diff",
                query=(
                    "The host edit path did not emit a usable result event. "
                    f"Inspect the live Git diff for {state.repair_plan.path}."
                ),
                success_condition=(
                    "Return a non-empty Git diff proving the implementation "
                    "change and showing that protected tests were untouched."
                ),
                parameters={"path": state.repair_plan.path},
            )
        normalized_answer = (answer or "").strip()
        runtime = self.runtime
        if (
            runtime is not None
            and state.cortheon_session_id is not None
            and state.evidence_ids
            and normalized_answer
            and state.pending_request is None
        ):
            completion_answer = normalized_answer[:4_000]
            hypothesis = completion_answer[:1_500]
            falsification = (
                state.last_success_condition or "Re-run the requested host evidence operation."
            )[:1_500]
            try:
                completed = runtime.complete(
                    state.cortheon_session_id,
                    answer=completion_answer,
                    claims=[
                        {
                            "claim": completion_answer,
                            "evidence_ids": list(state.evidence_ids),
                        }
                    ],
                    hypotheses=[
                        {
                            "statement": hypothesis,
                            "falsification_test": falsification,
                            "status": "supported",
                            "evidence_ids": list(state.evidence_ids),
                        }
                    ],
                    completion_evidence_ids=list(state.evidence_ids),
                )
            except (KeyError, RuntimeError, ValueError) as exc:
                completed = {
                    "status": "needs_evidence",
                    "next_action": state.pending_request,
                    "error": str(exc)[:500],
                }
            if completed.get("status") == "complete":
                self._mark_certified(state)
                self._metrics["hook_auto_completed"] += 1
                del self._turns[key]
                return {
                    "tracked": True,
                    "allow": True,
                    "certified": True,
                    "automatic": True,
                }
            self._capture_next_action(state, completed)
            self._metrics["hook_auto_withheld"] += 1

        state.stop_continuations += 1
        self._metrics["hook_continuations"] += 1
        continuation_limit = (
            MAX_PATCH_STOP_CONTINUATIONS_PER_TURN
            if state.deliverable == "code_change"
            else MAX_STOP_CONTINUATIONS_PER_TURN
        )
        if state.stop_continuations > continuation_limit:
            return self._release_uncertified(key, state)
        return {
            "tracked": True,
            "allow": False,
            "reason": _continuation_reason(state),
            **self._response(state),
        }

    def _manual_stop(self, key: str, state: HookTurn) -> dict[str, Any]:
        state.updated_at = time.monotonic()
        state.stop_continuations += 1
        self._metrics["hook_continuations"] += 1
        if state.stop_continuations > MAX_STOP_CONTINUATIONS_PER_TURN:
            return self._release_uncertified(key, state)
        if not state.started:
            reason = (
                "Completion is withheld: call `cortheon_start` with the user's "
                "exact goal and follow its `next_action`."
            )
        elif not state.observed:
            reason = (
                "Completion is withheld: obtain the requested host evidence and "
                "call `cortheon_observe` with its focused result."
            )
        else:
            reason = (
                "Completion is withheld: call `cortheon_complete`; if rejected, "
                "follow the returned `next_action`."
            )
        return {
            "tracked": True,
            "allow": False,
            "reason": reason,
            **self._response(state),
        }

    def _nudge_start(self, state: HookTurn) -> dict[str, Any]:
        """Let investigation tools through pre-start; enforcement waits at stop.

        Denying host tools before ``cortheon_start`` is what weak models doom-loop
        on: they retry the denied tool instead of reading the denial. Cortheon now
        steps back during investigation and stands in at completion time.
        """

        return {
            "tracked": True,
            "allow": True,
            "guidance": (
                "Cortheon is active for this turn. Investigate freely with host "
                "tools, then call `cortheon_start` with the user's exact goal "
                "before answering; completion is withheld until certified."
            ),
            **self._response(state),
        }

    def _release_uncertified(self, key: str, state: HookTurn) -> dict[str, Any]:
        """End a stuck turn by releasing the answer with an explicit caveat.

        Withholding the answer outright after the continuation budget ran out
        left the host/model pair with nothing to show, which restarted the same
        doomed cycle on the next prompt. Repeated failures trip a per-session
        circuit breaker that degrades Cortheon to passthrough."""

        self._discard_runtime_session(state)
        del self._turns[key]
        self._record_turn_failure(state.host_session_hash)
        self._metrics["hook_uncertified_releases"] += 1
        return {
            "tracked": True,
            "allow": True,
            "terminal": True,
            "certified": False,
            "uncertified": True,
            "caveat": UNCERTIFIED_RELEASE_CAVEAT,
            "systemMessage": UNCERTIFIED_RELEASE_CAVEAT,
        }

    def _record_turn_failure(self, host_hash: str) -> None:
        if len(self._session_failures) >= 1_024:
            self._session_failures.clear()
        self._session_failures[host_hash] = self._session_failures.get(host_hash, 0) + 1

    def _deny_requested_capability(
        self,
        state: HookTurn,
        capability: str,
    ) -> dict[str, Any]:
        if state.tool_denials >= MAX_TOOL_DENIALS_PER_TURN:
            return {
                "tracked": True,
                "allow": True,
                "degraded": True,
                **self._response(state),
            }
        state.tool_denials += 1
        self._metrics["hook_tools_denied"] += 1
        request = state.pending_request or {}
        query = str(request.get("query") or "")[:500]
        return {
            "tracked": True,
            "allow": False,
            "reason": (
                f"Cortheon is already active. Use a host {capability or 'evidence'} "
                f"tool for this request: {query}"
            ),
            **self._response(state),
        }

    def _capture_next_action(
        self,
        state: HookTurn,
        payload: dict[str, Any],
    ) -> None:
        cognition = payload.get("cognition")
        state.cognition = (
            _bounded_cognition(cognition)
            if isinstance(cognition, dict)
            else state.cognition
        )
        next_action = payload.get("next_action")
        state.last_next_action = (
            copy.deepcopy(next_action) if isinstance(next_action, dict) else None
        )
        request = (
            next_action.get("request")
            if isinstance(next_action, dict) and next_action.get("type") == "harness_tool"
            else None
        )
        state.pending_request = copy.deepcopy(request) if isinstance(request, dict) else None
        state.pending_origin = "runtime" if isinstance(request, dict) else None
        if isinstance(request, dict):
            state.last_success_condition = str(request.get("success_condition") or "")[:1_500]

    def _response(self, state: HookTurn) -> dict[str, Any]:
        response: dict[str, Any] = {
            **self._public_state(state),
            "automatic": state.automatic,
        }
        if state.cognition is not None:
            response["cognition"] = copy.deepcopy(state.cognition)
        if state.pending_request is not None:
            response["next_action"] = {
                "type": "harness_tool",
                "instruction": (
                    "Run this evidence request with the host's real tools. "
                    "The Codex hook will observe the result automatically."
                ),
                "request": copy.deepcopy(state.pending_request),
            }
        elif state.last_next_action is not None and not str(
            state.last_next_action.get("submit_via") or ""
        ).startswith("cortheon_"):
            response["next_action"] = copy.deepcopy(state.last_next_action)
        return response

    @staticmethod
    def _public_state(state: HookTurn) -> dict[str, bool]:
        return {
            "started": state.started,
            "observed": state.observed,
            "certified": state.certified,
        }

    def _mark_certified(self, state: HookTurn) -> None:
        if not state.certified:
            state.certified = True
            self._metrics["hook_turns_certified"] += 1

    def _discard_runtime_session(self, state: HookTurn) -> None:
        if self.runtime is None or state.cortheon_session_id is None:
            return
        with contextlib.suppress(KeyError, RuntimeError, ValueError):
            self.runtime.finish(state.cortheon_session_id, mode="abandon")
        state.cortheon_session_id = None

    @classmethod
    def _identifiers(
        cls,
        host: str,
        host_session_id: str,
        turn_id: str,
    ) -> tuple[str, str]:
        normalized_host = _bounded(host, "host", maximum=64).lower()
        normalized_session = _bounded(
            host_session_id,
            "host_session_id",
            maximum=512,
        )
        normalized_turn = _bounded(turn_id, "turn_id", maximum=512)
        host_hash = cls._host_hash(normalized_host, normalized_session)
        key = hashlib.sha256(
            f"{normalized_host}\0{normalized_session}\0{normalized_turn}".encode()
        ).hexdigest()
        return key, host_hash

    @staticmethod
    def _host_hash(host: str, host_session_id: str) -> str:
        normalized_host = _bounded(host, "host", maximum=64).lower()
        normalized_session = _bounded(
            host_session_id,
            "host_session_id",
            maximum=512,
        )
        return hashlib.sha256(f"{normalized_host}\0{normalized_session}".encode()).hexdigest()

    def _purge_expired(self) -> None:
        threshold = time.monotonic() - self.ttl_seconds
        expired = [key for key, state in self._turns.items() if state.updated_at < threshold]
        for key in expired:
            self._discard_runtime_session(self._turns[key])
            del self._turns[key]
        self._metrics["hook_turns_expired"] += len(expired)

    def _evict_oldest(self) -> None:
        if not self._turns:
            return
        oldest = min(self._turns, key=lambda key: self._turns[key].updated_at)
        self._discard_runtime_session(self._turns[oldest])
        del self._turns[oldest]
        self._metrics["hook_turns_expired"] += 1


def _is_shell_tool(tool_name: str) -> bool:
    return tool_name.casefold() in {"bash", "shell", "exec_command"}


def _is_apply_patch_tool(tool_name: str) -> bool:
    normalized = tool_name.casefold()
    return normalized == "apply_patch" or normalized.endswith("__apply_patch")


def _safe_command(request: dict[str, Any]) -> str | None:
    capability = str(request.get("capability") or "")
    parameters = request.get("parameters")
    if not isinstance(parameters, dict):
        return None
    if capability == "grep":
        pattern = parameters.get("pattern")
        path = parameters.get("path")
        if not isinstance(pattern, str) or not _safe_relative_path(path):
            return None
        return f"rg -n --fixed-strings -- {shlex.quote(pattern)} {shlex.quote(str(path))}"
    if capability == "read_many":
        paths = parameters.get("paths")
        if (
            not isinstance(paths, list)
            or not paths
            or not all(_safe_relative_path(path) for path in paths)
        ):
            return None
        covered = {
            str(item)
            for item in (request.get("covered_paths") or ())
            if isinstance(item, str)
        }
        remaining = [path for path in paths if str(path) not in covered]
        if not remaining:
            return None
        request_id = str(request.get("request_id") or "request")
        if re.fullmatch(r"[A-Za-z0-9_-]{1,128}", request_id) is None:
            return None
        marker = f"{_FILE_MARKER_PREFIX}{request_id}]"
        return (
            "for cortheon_path in "
            + " ".join(shlex.quote(str(path)) for path in remaining)
            + "; do "
            + f"printf '%s %s\\n' {shlex.quote(marker)} \"$cortheon_path\"; "
            + "sed -n '1,220p' \"$cortheon_path\" || exit; "
            + "done"
        )
    if capability == "diff":
        path = parameters.get("path")
        paths = parameters.get("paths")
        selected = (
            [path]
            if _safe_relative_path(path)
            else paths
            if isinstance(paths, list)
            and paths
            and all(_safe_relative_path(item) for item in paths)
            else None
        )
        if not selected:
            return None
        return "git diff -- " + " ".join(shlex.quote(str(item)) for item in selected)
    if capability == "test":
        command = parameters.get("command")
        if (
            not isinstance(command, list)
            or len(command) < 2
            or not all(
                isinstance(item, str)
                and item
                and "\x00" not in item
                and "\n" not in item
                and "\r" not in item
                and not item.startswith("/")
                and ".." not in item.split("/")
                for item in command
            )
        ):
            return None
        return shlex.join(command)
    return None


def _safe_relative_path(value: Any) -> bool:
    if not isinstance(value, str) or not value or len(value) > 500:
        return False
    if value.startswith(("/", "~")) or "\x00" in value or "\\" in value or ":" in value:
        return False
    return all(part not in {"", ".", ".."} for part in value.split("/"))


def _classify_host_tool(tool_name: str, command: str) -> str:
    """Map an actually-run host command or tool onto a logical receipt tool."""

    if command:
        try:
            tokens = shlex.split(command)
        except ValueError:
            tokens = command.split()
        first = tokens[0].rsplit("/", 1)[-1].casefold() if tokens else ""
        second = tokens[1].casefold() if len(tokens) > 1 else ""
        if first == "git" and second == "grep":
            return "grep"
        if first in {"rg", "grep", "egrep", "fgrep", "zgrep"}:
            return "grep"
        if first in {"cat", "sed", "awk", "head", "tail", "less", "more", "bat", "nl"}:
            return "read"
        if first in {"find", "fd", "ls", "tree", "locate"}:
            return "find"
        if first in {"curl", "wget"}:
            return "webfetch"
        return "read"
    normalized = tool_name.casefold()
    if "fetch" in normalized:
        return "webfetch"
    if "search" in normalized:
        return "websearch"
    if "grep" in normalized:
        return "grep"
    if "glob" in normalized or "find" in normalized or "list" in normalized:
        return "find"
    return "read"


def _host_receipt_arguments(
    tool: str,
    *,
    host_command: str,
    host_input: dict[str, Any],
    fallback_query: str,
    request_parameters: dict[str, Any],
) -> dict[str, Any]:
    """Describe the model-owned host action without changing it.

    Generic shell tools need a little normalization so a real ``cat file`` can
    satisfy a read request. The original command is always retained and a
    structured file path is added only when it can be recovered unambiguously.
    """

    if host_command:
        arguments: dict[str, Any] = {"command": host_command}
        if tool == "read":
            path = _read_path_from_command(host_command)
            if path is not None:
                arguments["filePath"] = path
        elif tool == "grep":
            try:
                tokens = shlex.split(host_command)
            except ValueError:
                tokens = []
            pattern = request_parameters.get("pattern")
            path = request_parameters.get("path")
            if isinstance(pattern, str) and pattern in tokens:
                arguments["pattern"] = pattern
            if isinstance(path, str) and any(
                token == path or token.replace("\\", "/").endswith("/" + path)
                for token in tokens
            ):
                arguments["path"] = path
        return arguments
    arguments = copy.deepcopy(host_input)
    if tool == "read":
        path = next(
            (
                arguments[key]
                for key in ("filePath", "file_path", "path", "filename")
                if isinstance(arguments.get(key), str) and arguments[key]
            ),
            None,
        )
        if path is not None:
            arguments["filePath"] = path
    elif tool == "grep":
        pattern = next(
            (
                arguments[key]
                for key in ("pattern", "query")
                if isinstance(arguments.get(key), str) and arguments[key]
            ),
            None,
        )
        path = next(
            (
                arguments[key]
                for key in ("path", "filePath", "file_path")
                if isinstance(arguments.get(key), str) and arguments[key]
            ),
            None,
        )
        if pattern is not None:
            arguments["pattern"] = pattern
        if path is not None:
            arguments["path"] = path
    if not arguments:
        arguments["query"] = fallback_query
    return arguments


def _read_path_from_command(command: str) -> str | None:
    """Recover one literal file operand from a simple read-only command."""

    stripped = re.sub(r"\s2>\s*/dev/null|\s2>&1|\s</dev/null", " ", command).strip()
    if not stripped or re.search(r"[`<>]|\$\(|\|\||&&|[;|&]", stripped):
        return None
    try:
        tokens = shlex.split(stripped)
    except ValueError:
        return None
    if len(tokens) < 2:
        return None
    reader = tokens[0].rsplit("/", 1)[-1].casefold()
    if reader not in {
        "cat",
        "bat",
        "sed",
        "awk",
        "head",
        "tail",
        "less",
        "more",
        "nl",
        "wc",
        "file",
        "stat",
    }:
        return None
    candidates = [
        token
        for token in tokens[1:]
        if token
        and not token.startswith("-")
        and not token.isdigit()
        and not re.fullmatch(r"\d+(?:,\d+)?[a-z]?", token, flags=re.IGNORECASE)
    ]
    if not candidates:
        return None
    candidate = candidates[-1]
    if "\x00" in candidate or candidate in {".", ".."}:
        return None
    return candidate


def _host_observations(
    request: dict[str, Any],
    tool_name: str,
    tool_output: str,
    *,
    succeeded: bool,
    host_command: str = "",
    host_input: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    capability = str(request.get("capability") or "")
    parameters = request.get("parameters")
    if not isinstance(parameters, dict):
        parameters = {}
    output = tool_output.strip()[:MAX_HOOK_EVIDENCE_CHARS]
    if capability == "edit":
        return []
    if host_command or host_input or capability not in {"grep", "read_many", "diff", "test"}:
        # Investigation-phase harvest: the model ran its own allowed command or
        # host tool, so build an honest receipt from what actually executed.
        tool = _classify_host_tool(tool_name, host_command)
        if tool == "grep":
            outcome = "match" if output else "no_match"
        elif not succeeded:
            outcome = "error"
        else:
            outcome = "result" if output else "no_match"
        arguments = _host_receipt_arguments(
            tool,
            host_command=host_command,
            host_input=host_input or {},
            fallback_query=str(request.get("query") or "")[:200],
            request_parameters=parameters,
        )
        receipt = {
            "tool": tool,
            "executor": tool_name,
            "outcome": outcome,
            "args": arguments,
        }
        kind = "other" if tool in {"websearch", "webfetch"} else "code"
        return [
            _observation(
                kind,
                output or "No output.",
                receipt,
                status="failed" if not succeeded else "observed",
            )
        ]
    if capability == "grep":
        outcome = "match" if output else "no_match"
        receipt = {
            "tool": "grep",
            "executor": tool_name,
            "outcome": outcome,
            "args": {
                "pattern": parameters.get("pattern"),
                "path": parameters.get("path"),
            },
        }
        return [_observation("code", output or "No matches found.", receipt)]
    if capability == "read_many":
        paths = parameters.get("paths")
        if not isinstance(paths, list):
            return []
        split = _split_read_many_output(
            output,
            request_id=str(request.get("request_id") or ""),
            expected_paths=[item for item in paths if isinstance(item, str)],
        )
        if split is None:
            return []
        return [
            _observation(
                "code",
                split[path],
                {
                    "tool": "read",
                    "executor": tool_name,
                    "outcome": "result" if succeeded else "error",
                    "args": {"filePath": path},
                },
                status="verified" if succeeded else "failed",
            )
            for path in paths
            if isinstance(path, str) and path in split
        ]
    if capability == "diff":
        changed = succeeded and bool(output)
        receipt = {
            "tool": "diff",
            "executor": tool_name,
            "outcome": "changed" if changed else "no_match",
            "args": copy.deepcopy(parameters),
        }
        return [
            _observation(
                "diff",
                output or "No diff.",
                receipt,
                status="verified" if changed else "failed",
            )
        ]
    if capability == "test":
        receipt = {
            "tool": "test",
            "executor": tool_name,
            "outcome": "passed" if succeeded else "failed",
            "args": copy.deepcopy(parameters),
        }
        return [
            _observation(
                "test",
                output or "No test output.",
                receipt,
                status="verified" if succeeded else "failed",
            )
        ]
    return []


def _observation(
    kind: str,
    content: str,
    receipt: dict[str, Any],
    *,
    status: str = "verified",
) -> dict[str, Any]:
    prefix = "[CORTHEON_HOST_EVIDENCE] " + json.dumps(
        receipt,
        sort_keys=True,
        separators=(",", ":"),
    )
    return {
        "kind": kind,
        "content": f"{prefix}\n{content}",
        "source": f"codex:{receipt['executor']}",
        "status": status,
    }


def _split_read_many_output(
    output: str,
    *,
    request_id: str,
    expected_paths: list[str],
) -> dict[str, str] | None:
    if not expected_paths:
        return None
    marker = f"{_FILE_MARKER_PREFIX}{request_id}] "
    current: str | None = None
    captured: dict[str, list[str]] = {}
    expected = set(expected_paths)
    for line in output.splitlines():
        if line.startswith(marker):
            candidate = line[len(marker) :]
            current = candidate if candidate in expected else None
            if current is not None:
                captured.setdefault(current, [])
            continue
        if current is not None:
            captured[current].append(line)
    if set(captured) != expected:
        if len(expected_paths) == 1 and marker not in output:
            return {expected_paths[0]: output}
        # Host output truncation can cut off later files; accept the files that
        # did arrive so the request can converge over follow-up reads instead of
        # re-running the identical command forever.
        partial = {
            path: "\n".join(captured[path]).strip()[:MAX_HOOK_EVIDENCE_CHARS]
            for path in expected_paths
            if captured.get(path)
        }
        return partial or None
    return {
        path: "\n".join(captured[path]).strip()[:MAX_HOOK_EVIDENCE_CHARS] for path in expected_paths
    }


def _read_snapshots(
    observations: list[dict[str, Any]],
) -> list[tuple[str, str]]:
    snapshots: list[tuple[str, str]] = []
    for observation in observations:
        content = observation.get("content")
        if not isinstance(content, str):
            continue
        lines = content.splitlines()
        if not lines or not lines[0].startswith("[CORTHEON_HOST_EVIDENCE] "):
            continue
        try:
            receipt = json.loads(lines[0][len("[CORTHEON_HOST_EVIDENCE] ") :])
        except json.JSONDecodeError:
            continue
        arguments = receipt.get("args") if isinstance(receipt, dict) else None
        path = arguments.get("filePath") if isinstance(arguments, dict) else None
        if isinstance(path, str):
            snapshots.append((path, "\n".join(lines[1:])))
    return snapshots


def _attempts_protected_mutation(
    tool_name: str,
    tool_input: dict[str, Any],
    *,
    protected_paths: tuple[str, ...],
    protects_all_tests: bool,
) -> bool:
    if not protected_paths and not protects_all_tests:
        return False
    serialized = json.dumps(
        tool_input,
        separators=(",", ":"),
        ensure_ascii=False,
    )
    candidates = set(protected_paths)
    if protects_all_tests:
        candidates.update(
            match.group(0)
            for match in re.finditer(
                r"[A-Za-z0-9_./-]+\.(?:py|js|jsx|ts|tsx|go|rs|java)",
                serialized,
            )
            if is_test_path(match.group(0))
        )
    if not any(path in serialized for path in candidates):
        return False
    if _is_apply_patch_tool(tool_name) or tool_name.casefold() in {
        "edit",
        "write",
        "delete",
        "move",
    }:
        return True
    if not _is_shell_tool(tool_name):
        return False
    command = str(tool_input.get("command") or tool_input.get("cmd") or "")
    mutation = re.search(
        r"(?:^|[;&|]\s*)(?:apply_patch|rm|mv|cp|tee)\b|"
        r"\bsed\s+-i\b|\bperl\s+-[^\s]*i|\btruncate\b|"
        r"(?:^|[^>])>{1,2}(?:[^>]|$)",
        command,
    )
    return mutation is not None


def _continuation_reason(state: HookTurn) -> str:
    if state.pending_request is not None:
        query = str(state.pending_request.get("query") or "")[:800]
        return (
            "Cortheon withheld completion. Continue with this host evidence "
            f"request, then answer again: {query}"
        )
    if not state.evidence_ids:
        return (
            "Cortheon withheld completion because no verified host evidence was "
            "captured. Run the task's relevant read, search, diff, or test tool."
        )
    return (
        "Cortheon withheld completion because the evidence contract still has an "
        "unresolved gap. Continue the investigation and answer again."
    )


def _bounded(value: str, field: str, *, maximum: int = 1_024) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field} must be a non-empty string")
    normalized = value.strip()
    if len(normalized) > maximum:
        raise ValueError(f"{field} exceeds {maximum} characters")
    return normalized
