"""Bounded repair planning for native Cortheon host adapters.

The helpers in this module never open or retain a project file.  A trusted host
adapter supplies focused, live excerpts and remains responsible for applying
the returned edit with its own tool.
"""

from __future__ import annotations

import ast
import operator
import re
import shlex
from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import PurePosixPath
from typing import Any

_TEST_PATH_RE = re.compile(
    r"\b[A-Za-z0-9_./-]*(?:test[^/\s]*|[^/\s]*_test)"
    r"\.(?:py|js|jsx|ts|tsx|go|rs|java)\b",
    flags=re.IGNORECASE,
)
_PROTECT_TEST_RE = re.compile(
    r"\b(?:do\s+not|don't|must\s+not|without)\s+"
    r"(?:chang(?:e|ing)|modif(?:y|ying)|edit(?:ing)?)\s+"
    r"(?:the\s+)?(?:tests?\b|[A-Za-z0-9_./-]*(?:test[^/\s]*|[^/\s]*_test)"
    r"\.(?:py|js|jsx|ts|tsx|go|rs|java)\b)",
    flags=re.IGNORECASE,
)
_SAFE_COMMAND_RE = re.compile(r"^[A-Za-z0-9_./:=,@+\- \t]+$")
_SIMPLE_LITERAL_RE = re.compile(r"^[+-]?(?:\d+(?:\.\d*)?|\.\d+)$")


@dataclass(frozen=True, slots=True)
class RepairPlan:
    """One exact, single-line replacement supported by live examples."""

    path: str
    old_text: str
    new_text: str
    function_name: str
    examples: int

    def patch(self) -> str:
        """Return an ``apply_patch`` transaction for the host to execute."""

        return (
            "*** Begin Patch\n"
            f"*** Update File: {self.path}\n"
            "@@\n"
            f"-{self.old_text}\n"
            f"+{self.new_text}\n"
            "*** End Patch\n"
        )


@dataclass(frozen=True, slots=True)
class TestInvocation:
    """A parsed, allow-listed test command copied from the user's goal."""

    command_line: str
    executable: str
    arguments: tuple[str, ...]

    def shell_command(self) -> str:
        return shlex.join((self.executable, *self.arguments))


def requested_test_invocation(task: str) -> TestInvocation | None:
    """Extract one safe test invocation explicitly requested by the user."""

    match = re.search(
        r"\brun\s+(.+?)(?=\s+after\b|\s+and\s+(?:report|verify|then)\b|$)",
        task,
        flags=re.IGNORECASE,
    )
    if match is None:
        return None
    command_line = match.group(1).strip("`'\" ").strip()
    if (
        not command_line
        or len(command_line) > 1_000
        or "\r" in command_line
        or "\n" in command_line
        or _SAFE_COMMAND_RE.fullmatch(command_line) is None
    ):
        return None
    try:
        tokens = shlex.split(command_line)
    except ValueError:
        return None
    if len(tokens) < 2 or any(not _safe_command_token(item) for item in tokens):
        return None

    executable, arguments = tokens[0], tokens[1:]
    name = executable.removeprefix("./").casefold()
    python_test = re.fullmatch(r"python(?:3(?:\.\d+)?)?", name) is not None and arguments[:2] in (
        ["-m", "pytest"],
        ["-m", "unittest"],
    )
    direct_pytest = name in {"pytest", "py.test"}
    node_test = name in {"npm", "pnpm", "yarn", "bun"} and (
        arguments[:1] == ["test"] or arguments[:2] == ["run", "test"]
    )
    compiled_test = (
        (name == "cargo" and arguments[:1] == ["test"])
        or (name == "go" and arguments[:1] == ["test"])
        or (name == "dotnet" and arguments[:1] == ["test"])
        or (
            name in {"mvn", "mvnw", "gradle", "gradlew"}
            and any(re.search(r"\btest\b", item, flags=re.IGNORECASE) for item in arguments)
        )
    )
    if not (python_test or direct_pytest or node_test or compiled_test):
        return None
    if any(
        item == "--basetemp"
        or item.startswith("--basetemp=")
        or item == "--rootdir"
        or item.startswith("--rootdir=")
        for item in arguments
    ):
        return None
    return TestInvocation(
        command_line=command_line,
        executable=executable,
        arguments=tuple(arguments),
    )


def requested_check_invocation(task: str) -> TestInvocation | None:
    """Extract one safe lint/type-check invocation explicitly requested by the user.

    This scans every ``run <command>`` clause (the first is usually the test
    contract) and returns the first allow-listed quality check, so the host
    patch loop can chain a deterministic lint/type gate after the tests pass.
    """

    for match in re.finditer(
        r"\brun\s+(.+?)(?=\s+after\b|\s+and\s+(?:report|verify|then)\b|$)",
        task,
        flags=re.IGNORECASE,
    ):
        invocation = _check_invocation_from(match.group(1))
        if invocation is not None:
            return invocation
    return None


def _check_invocation_from(raw: str) -> TestInvocation | None:
    command_line = raw.strip("`'\" ").strip()
    if (
        not command_line
        or len(command_line) > 1_000
        or "\r" in command_line
        or "\n" in command_line
        or _SAFE_COMMAND_RE.fullmatch(command_line) is None
    ):
        return None
    try:
        tokens = shlex.split(command_line)
    except ValueError:
        return None
    if len(tokens) < 2 or any(not _safe_command_token(item) for item in tokens):
        return None

    executable, arguments = tokens[0], tokens[1:]
    name = executable.removeprefix("./").casefold()
    ruff_check = name == "ruff" and arguments[:1] == ["check"]
    python_check = re.fullmatch(r"python(?:3(?:\.\d+)?)?", name) is not None and arguments[:2] in (
        ["-m", "ruff"],
        ["-m", "mypy"],
        ["-m", "pyright"],
        ["-m", "flake8"],
    )
    direct_check = name in {"mypy", "pyright", "flake8", "eslint", "tsc", "biome"}
    compiled_check = (name == "cargo" and arguments[:1] == ["clippy"]) or (
        name == "go" and arguments[:1] == ["vet"]
    )
    if not (ruff_check or python_check or direct_check or compiled_check):
        return None
    return TestInvocation(
        command_line=command_line,
        executable=executable,
        arguments=tuple(arguments),
    )


def protects_tests(task: str) -> bool:
    """Return whether the user explicitly prohibited test mutation."""

    return _PROTECT_TEST_RE.search(task) is not None


def protected_test_paths(task: str) -> tuple[str, ...]:
    """Return named test paths covered by an explicit no-mutation constraint."""

    if not protects_tests(task):
        return ()
    return tuple(dict.fromkeys(_TEST_PATH_RE.findall(task)))[:12]


def is_test_path(path: str) -> bool:
    """Recognize conventional test filenames without consulting the filesystem."""

    name = PurePosixPath(path).name.casefold()
    return (
        name.startswith("test_")
        or "_test." in name
        or name.endswith((".spec.js", ".spec.jsx", ".spec.ts", ".spec.tsx"))
        or name.endswith((".test.js", ".test.jsx", ".test.ts", ".test.tsx"))
    )


def derive_repair_candidates(
    reads: Iterable[tuple[str, str]],
    *,
    limit: int = 3,
) -> list[RepairPlan]:
    """Derive ranked expression repairs that satisfy observed literal examples.

    This deliberately handles only a small, auditable class: one Python return
    expression and literal assertions against that function.  Several distinct
    candidates can satisfy the observed examples (the examples underdetermine
    the fix); returning the ranked survivors lets the host try them best-of-N
    against the real test suite instead of betting everything on one guess.
    Ambiguous or unsupported inputs return an empty list and leave the
    model/host in control.
    """

    snapshots = [(path, source) for path, source in reads if path and source]
    implementation = next(
        ((path, source) for path, source in snapshots if not is_test_path(path)),
        None,
    )
    if implementation is None:
        return []
    implementation_path, implementation_source = implementation
    function = _first_simple_return(implementation_source)
    if function is None:
        return []
    function_name, parameters, return_line, return_expression = function

    test_source = "\n".join(source for path, source in snapshots if path != implementation_path)
    examples = _literal_examples(
        test_source,
        function_name=function_name,
        parameter_count=len(parameters),
    )
    if not examples:
        return []

    candidates = _candidate_expressions(return_expression, parameters)
    passing = [
        candidate
        for candidate in candidates
        if all(
            _matches_expected(
                _evaluate_expression(candidate, parameters, values),
                expected,
            )
            for values, expected in examples
        )
    ]
    if not passing:
        return []
    original_operator = _root_operator(return_expression, parameters[0])
    passing.sort(
        key=lambda candidate: (
            int(
                original_operator is not None
                and _root_operator(candidate, parameters[0]) != original_operator
            ),
            _expression_distance(candidate, return_expression),
            candidate,
        )
    )
    return [
        RepairPlan(
            path=implementation_path,
            old_text=return_line,
            new_text=return_line.replace(return_expression, replacement, 1),
            function_name=function_name,
            examples=len(examples),
        )
        for replacement in passing[: max(1, limit)]
    ]


def derive_simple_repair(
    reads: Iterable[tuple[str, str]],
) -> RepairPlan | None:
    """Return the single best-ranked repair candidate, or ``None``."""

    candidates = derive_repair_candidates(reads, limit=1)
    return candidates[0] if candidates else None


def changed_paths_from_diff(content: str) -> set[str]:
    """Return normalized paths named by a unified Git diff."""

    paths: set[str] = set()
    for line in content.splitlines():
        candidate: str | None = None
        if line.startswith("diff --git "):
            try:
                parts = shlex.split(line)
            except ValueError:
                continue
            if len(parts) >= 4:
                candidate = parts[3]
        elif line.startswith("+++ ") or line.startswith("--- "):
            candidate = line[4:].split("\t", 1)[0].strip()
        elif line.startswith("*** Update File: "):
            candidate = line[len("*** Update File: ") :].strip()
        elif line.startswith("*** Add File: "):
            candidate = line[len("*** Add File: ") :].strip()
        elif line.startswith("*** Delete File: "):
            candidate = line[len("*** Delete File: ") :].strip()
        if not candidate or candidate == "/dev/null":
            continue
        if candidate.startswith(("a/", "b/")):
            candidate = candidate[2:]
        if candidate:
            paths.add(candidate)
    return paths


def _safe_command_token(value: str) -> bool:
    if (
        not value
        or "\x00" in value
        or "\\" in value
        or ":" in value
        or PurePosixPath(value).is_absolute()
    ):
        return False
    return all(part != ".." for part in PurePosixPath(value).parts)


def _first_simple_return(
    source: str,
) -> tuple[str, list[str], str, str] | None:
    lines = source.splitlines()
    for index, line in enumerate(lines):
        definition = re.match(
            r"^\s*def\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(([^)]*)\)",
            line,
        )
        if definition is None:
            continue
        parameters = [
            item.split("=", 1)[0].split(":", 1)[0].strip()
            for item in definition.group(2).split(",")
        ]
        parameters = [item for item in parameters if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", item)]
        for body_line in lines[index + 1 :]:
            if re.match(r"^\s*def\s+", body_line):
                break
            returned = re.match(r"^(\s+)return\s+([^#]+?)\s*$", body_line)
            if returned is not None and parameters:
                return (
                    definition.group(1),
                    parameters,
                    body_line,
                    returned.group(2).strip(),
                )
    return None


def _simple_literal(value: str) -> int | float | bool | None:
    text = value.strip()
    if text == "True":
        return True
    if text == "False":
        return False
    if _SIMPLE_LITERAL_RE.fullmatch(text) is None:
        return None
    return float(text) if "." in text else int(text)


def _literal_examples(
    source: str,
    *,
    function_name: str,
    parameter_count: int,
) -> list[tuple[tuple[int | float | bool, ...], int | float | bool]]:
    assertion = re.compile(
        rf"\b{re.escape(function_name)}\s*\(([^()]*)\)\s*"
        r"(?:==|is)\s*"
        r"([+-]?(?:\d+(?:\.\d*)?|\.\d+)|True|False)"
    )
    examples: list[tuple[tuple[int | float | bool, ...], int | float | bool]] = []
    for match in assertion.finditer(source):
        values = tuple(_simple_literal(item) for item in match.group(1).split(","))
        expected = _simple_literal(match.group(2))
        if (
            len(values) == parameter_count
            and all(item is not None for item in values)
            and expected is not None
        ):
            examples.append(
                (
                    tuple(item for item in values if item is not None),
                    expected,
                )
            )
    return examples


def _candidate_expressions(expression: str, parameters: list[str]) -> set[str]:
    candidates: set[str] = set()
    for operator_text in (" + ", " - ", " * ", " / ", " % "):
        if operator_text not in expression:
            continue
        for replacement in (" + ", " - ", " * ", " / ", " % "):
            if replacement != operator_text:
                candidates.add(expression.replace(operator_text, replacement, 1))
    if re.search(r"\b(?:min|max)\s*\(", expression):
        candidates.add(
            re.sub(
                r"\bmax\s*\(",
                "min(",
                re.sub(r"\bmin\s*\(", "__CORTHEON_MAX__(", expression),
            ).replace("__CORTHEON_MAX__(", "max(")
        )
    for left, right in (("== 0", "== 1"), ("== 1", "== 0"), ("!= 0", "!= 1"), ("!= 1", "!= 0")):
        if left in expression:
            candidates.add(expression.replace(left, right, 1))
    comparisons = (" < ", " <= ", " > ", " >= ")
    for comparison in comparisons:
        if comparison not in expression:
            continue
        for replacement in comparisons:
            if replacement != comparison:
                candidates.add(expression.replace(comparison, replacement, 1))
    for match in re.finditer(r"\b\d+\b", expression):
        value = int(match.group(0))
        for adjusted in (value - 1, value + 1):
            if adjusted >= 0:
                candidates.add(
                    expression[: match.start()] + str(adjusted) + expression[match.end() :]
                )
    operand_swap = re.fullmatch(
        r"\s*([A-Za-z_][A-Za-z0-9_]*)\s*([-/%])\s*([A-Za-z_][A-Za-z0-9_]*)\s*",
        expression,
    )
    if operand_swap is not None:
        left_name, operator_symbol, right_name = operand_swap.groups()
        candidates.add(f"{right_name} {operator_symbol} {left_name}")
    absolute = re.fullmatch(r"abs\((.+)\)", expression)
    if absolute is not None:
        candidates.add(absolute.group(1))
    elif len(expression) <= 60:
        candidates.add(f"abs({expression})")
    if expression.startswith("not "):
        candidates.add(expression[4:])
    elif len(expression) <= 60:
        candidates.add(f"not {expression}")
    if len(parameters) == 2:
        left, right = parameters
        candidates.update(
            {
                f"{left} + {right}",
                f"{left} - {right}",
                f"{left} * {right}",
                f"{left} + {left} * {right}",
                f"{left} - {left} * {right}",
                f"{left} * (1 + {right})",
                f"{left} * (1 - {right})",
            }
        )
    candidates.discard(expression)
    candidates.discard("")
    return candidates


_BINARY_OPERATORS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.Mod: operator.mod,
}
_UNARY_OPERATORS = {
    ast.UAdd: operator.pos,
    ast.USub: operator.neg,
    ast.Not: operator.not_,
}
_COMPARE_OPERATORS = {
    ast.Eq: operator.eq,
    ast.NotEq: operator.ne,
    ast.Lt: operator.lt,
    ast.LtE: operator.le,
    ast.Gt: operator.gt,
    ast.GtE: operator.ge,
}
_CALLS = {"min": min, "max": max, "abs": abs}


def _evaluate_expression(
    expression: str,
    parameters: list[str],
    values: tuple[int | float | bool, ...],
) -> Any:
    if len(expression) > 300:
        return None
    try:
        tree = ast.parse(expression, mode="eval")
        return _evaluate_node(tree.body, dict(zip(parameters, values, strict=True)))
    except (ArithmeticError, SyntaxError, TypeError, ValueError):
        return None


def _evaluate_node(node: ast.AST, environment: dict[str, Any]) -> Any:
    if isinstance(node, ast.Constant) and isinstance(
        node.value,
        (int, float, bool),
    ):
        return node.value
    if isinstance(node, ast.Name) and node.id in environment:
        return environment[node.id]
    if isinstance(node, ast.BinOp) and type(node.op) in _BINARY_OPERATORS:
        return _BINARY_OPERATORS[type(node.op)](
            _evaluate_node(node.left, environment),
            _evaluate_node(node.right, environment),
        )
    if isinstance(node, ast.UnaryOp) and type(node.op) in _UNARY_OPERATORS:
        return _UNARY_OPERATORS[type(node.op)](_evaluate_node(node.operand, environment))
    if (
        isinstance(node, ast.Call)
        and isinstance(node.func, ast.Name)
        and node.func.id in _CALLS
        and not node.keywords
    ):
        return _CALLS[node.func.id](*(_evaluate_node(item, environment) for item in node.args))
    if (
        isinstance(node, ast.Compare)
        and len(node.ops) == 1
        and len(node.comparators) == 1
        and type(node.ops[0]) in _COMPARE_OPERATORS
    ):
        return _COMPARE_OPERATORS[type(node.ops[0])](
            _evaluate_node(node.left, environment),
            _evaluate_node(node.comparators[0], environment),
        )
    raise ValueError("unsupported expression")


def _matches_expected(observed: Any, expected: int | float | bool) -> bool:
    if isinstance(expected, bool):
        return observed is expected
    return (
        isinstance(observed, (int, float))
        and not isinstance(observed, bool)
        and abs(float(observed) - float(expected)) <= 1e-9
    )


def _root_operator(expression: str, first_parameter: str) -> str | None:
    match = re.match(
        rf"^\s*{re.escape(first_parameter)}\s*([+*/%]|-)",
        expression,
    )
    return match.group(1) if match is not None else None


def _expression_distance(left: str, right: str) -> float:
    distance = abs(len(left) - len(right))
    distance += sum(
        left_item != right_item for left_item, right_item in zip(left, right, strict=False)
    )
    return distance + max(len(left), len(right)) / 10_000
